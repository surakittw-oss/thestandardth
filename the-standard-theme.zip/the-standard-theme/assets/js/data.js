// THE STANDARD — article data
// Uses double-quoted strings throughout; Thai quotation marks use Unicode \u2018\u2019

window.ARTICLES = [
  {
    id: "social-security",
    category: "POLITICS",
    title: "\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e15\u0e31\u0e49\u0e07 2569 : \u0e2a\u0e27. \u0e40\u0e1b\u0e34\u0e14\u0e1e\u0e37\u0e49\u0e19\u0e17\u0e35\u0e48\u0e16\u0e01\u0e1b\u0e21 \u2018\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21\u2019 \u0e40\u0e0a\u0e34\u0e0d\u0e15\u0e31\u0e27\u0e41\u0e17\u0e19\u0e19\u0e32\u0e22\u0e08\u0e49\u0e32\u0e07-\u0e1c\u0e39\u0e49\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e15\u0e31\u0e27 \u0e41\u0e08\u0e07\u0e40\u0e2b\u0e15\u0e38\u0e1c\u0e25\u0e1b\u0e23\u0e30\u0e0a\u0e32\u0e1e\u0e34\u0e08\u0e32\u0e23\u0e13\u0e4c\u0e25\u0e48\u0e32\u0e0a\u0e49\u0e32",
    excerpt: "\u0e04\u0e13\u0e30\u0e01\u0e23\u0e23\u0e21\u0e32\u0e18\u0e34\u0e01\u0e32\u0e23\u0e27\u0e38\u0e12\u0e34\u0e2a\u0e20\u0e32\u0e40\u0e1b\u0e34\u0e14\u0e40\u0e27\u0e17\u0e35\u0e23\u0e31\u0e1a\u0e1f\u0e31\u0e07\u0e04\u0e27\u0e32\u0e21\u0e40\u0e2b\u0e47\u0e19\u0e15\u0e31\u0e27\u0e41\u0e17\u0e19\u0e1c\u0e39\u0e49\u0e40\u0e01\u0e35\u0e48\u0e22\u0e27\u0e02\u0e49\u0e2d\u0e07\u0e01\u0e23\u0e13\u0e35\u0e01\u0e32\u0e23\u0e1b\u0e23\u0e30\u0e0a\u0e32\u0e1e\u0e34\u0e08\u0e32\u0e23\u0e13\u0e4c\u0e23\u0e48\u0e32\u0e07\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21\u0e17\u0e35\u0e48\u0e16\u0e39\u0e01\u0e40\u0e25\u0e37\u0e48\u0e2d\u0e19",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/social-security-public-hearing.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "12 \u0e19\u0e32\u0e17\u0e35\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e01\u0e32\u0e23\u0e40\u0e21\u0e37\u0e2d\u0e07",
    readTime: "4 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "raab-11",
    category: "THAILAND",
    title: "\u0e28\u0e32\u0e25\u0e2d\u0e32\u0e0d\u0e32\u0e1e\u0e34\u0e1e\u0e32\u0e01\u0e29\u0e32\u0e08\u0e33\u0e04\u0e38\u0e01 4 \u0e41\u0e01\u0e19\u0e19\u0e33\u0e04\u0e14\u0e35\u0e0a\u0e38\u0e21\u0e19\u0e38\u0e21\u0e23\u0e32\u0e1a 11 \u0e04\u0e19\u0e25\u0e30 2 \u0e1b\u0e35 8 \u0e40\u0e14\u0e37\u0e2d\u0e19 \u0e22\u0e01\u0e1f\u0e49\u0e2d\u0e07 \u2018\u0e17\u0e23\u0e32\u0e22-\u0e41\u0e2b\u0e27\u0e19\u2019 \u0e02\u0e49\u0e2d\u0e2b\u0e32 \u0e21.112 \u0e41\u0e25\u0e30 \u0e21.116",
    excerpt: "\u0e28\u0e32\u0e25\u0e2d\u0e32\u0e0d\u0e32\u0e23\u0e31\u0e0a\u0e14\u0e32\u0e2f \u0e2d\u0e48\u0e32\u0e19\u0e04\u0e33\u0e1e\u0e34\u0e1e\u0e32\u0e01\u0e29\u0e32\u0e04\u0e14\u0e35\u0e0a\u0e38\u0e21\u0e19\u0e38\u0e21\u0e2b\u0e19\u0e49\u0e32\u0e23\u0e32\u0e1a 11 \u0e2a\u0e31\u0e48\u0e07\u0e08\u0e33\u0e04\u0e38\u0e01\u0e41\u0e01\u0e19\u0e19\u0e33 4 \u0e04\u0e19",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/raab-11-leaders-jailed.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "34 \u0e19\u0e32\u0e17\u0e35\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28\u0e44\u0e17\u0e22",
    readTime: "6 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "storm-warning",
    category: "THAILAND",
    title: "\u0e2d\u0e38\u0e15\u0e38\u0e2f \u0e40\u0e15\u0e37\u0e2d\u0e19\u0e23\u0e31\u0e1a\u0e21\u0e37\u0e2d\u0e1e\u0e32\u0e22\u0e38\u0e24\u0e14\u0e39\u0e23\u0e49\u0e2d\u0e19 23-25 \u0e01.\u0e1e. \u0e19\u0e35\u0e49 \u0e23\u0e30\u0e27\u0e31\u0e07\u0e1d\u0e19\u0e1f\u0e49\u0e32\u0e04\u0e30\u0e19\u0e2d\u0e07-\u0e25\u0e39\u0e01\u0e40\u0e2b\u0e47\u0e1a\u0e15\u0e01 \u0e40\u0e23\u0e34\u0e48\u0e21\u0e08\u0e32\u0e01\u0e2d\u0e35\u0e2a\u0e32\u0e19\u0e01\u0e48\u0e2d\u0e19\u0e40\u0e02\u0e49\u0e32\u0e1b\u0e01\u0e04\u0e25\u0e38\u0e21\u0e17\u0e31\u0e48\u0e27\u0e44\u0e17\u0e22\u0e15\u0e2d\u0e19\u0e1a\u0e19",
    excerpt: "\u0e01\u0e23\u0e21\u0e2d\u0e38\u0e15\u0e38\u0e19\u0e34\u0e22\u0e21\u0e27\u0e34\u0e17\u0e22\u0e32\u0e2d\u0e2d\u0e01\u0e1b\u0e23\u0e30\u0e01\u0e32\u0e28\u0e40\u0e15\u0e37\u0e2d\u0e19\u0e1e\u0e32\u0e22\u0e38\u0e24\u0e14\u0e39\u0e23\u0e49\u0e2d\u0e19\u0e0a\u0e48\u0e27\u0e07 23-25 \u0e01\u0e38\u0e21\u0e20\u0e32\u0e1e\u0e31\u0e19\u0e18\u0e4c \u0e23\u0e30\u0e27\u0e31\u0e07\u0e1d\u0e19\u0e1f\u0e49\u0e32\u0e04\u0e30\u0e19\u0e2d\u0e07 \u0e25\u0e39\u0e01\u0e40\u0e2b\u0e47\u0e1a \u0e41\u0e25\u0e30\u0e25\u0e21\u0e01\u0e23\u0e30\u0e42\u0e0a\u0e01\u0e41\u0e23\u0e07",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/thailand-summer-storm-warning.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "1 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28\u0e44\u0e17\u0e22",
    readTime: "3 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "agriculture",
    category: "POLITICS",
    title: "\u0e1b\u0e25\u0e31\u0e14\u0e40\u0e01\u0e29\u0e15\u0e23\u0e2f \u0e42\u0e15\u0e49\u0e1c\u0e39\u0e49\u0e1a\u0e23\u0e34\u0e2b\u0e32\u0e23\u0e1a\u0e34\u0e19\u0e22\u0e38\u0e42\u0e23\u0e1b\u0e23\u0e48\u0e27\u0e21 \u2018\u0e18\u0e23\u0e23\u0e21\u0e19\u0e31\u0e2a\u2019 \u0e22\u0e31\u0e19\u0e2b\u0e32\u0e01\u0e44\u0e1b\u0e15\u0e49\u0e2d\u0e07\u0e02\u0e2d\u0e2d\u0e19\u0e38\u0e0d\u0e32\u0e15\u0e01\u0e48\u0e2d\u0e19",
    excerpt: "\u0e1b\u0e25\u0e31\u0e14\u0e01\u0e23\u0e30\u0e17\u0e23\u0e27\u0e07\u0e40\u0e01\u0e29\u0e15\u0e23\u0e2f \u0e1b\u0e0f\u0e34\u0e40\u0e2a\u0e18\u0e02\u0e48\u0e32\u0e27\u0e04\u0e13\u0e30\u0e1c\u0e39\u0e49\u0e1a\u0e23\u0e34\u0e2b\u0e32\u0e23\u0e40\u0e14\u0e34\u0e19\u0e17\u0e32\u0e07\u0e44\u0e1b\u0e22\u0e38\u0e42\u0e23\u0e1b\u0e1e\u0e23\u0e49\u0e2d\u0e21 \u2018\u0e18\u0e23\u0e23\u0e21\u0e19\u0e31\u0e2a\u2019",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/agriculture-perm-sec-denies-europe-trip.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "2 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e01\u0e32\u0e23\u0e40\u0e21\u0e37\u0e2d\u0e07",
    readTime: "5 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "ai-traffic",
    category: "THAILAND",
    title: "\u0e01\u0e17\u0e21. \u0e15\u0e34\u0e14\u0e01\u0e25\u0e49\u0e2d\u0e07 AI \u0e04\u0e38\u0e21\u0e41\u0e22\u0e01\u0e08\u0e23\u0e32\u0e08\u0e23 74 \u0e08\u0e38\u0e14\u0e17\u0e31\u0e48\u0e27\u0e01\u0e23\u0e38\u0e07 \u0e40\u0e15\u0e23\u0e35\u0e22\u0e21\u0e02\u0e22\u0e32\u0e22\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e2d\u0e35\u0e01 50 \u0e41\u0e22\u0e01\u0e1b\u0e35\u0e19\u0e35\u0e49",
    excerpt: "\u0e01\u0e23\u0e38\u0e07\u0e40\u0e17\u0e1e\u0e21\u0e2b\u0e32\u0e19\u0e04\u0e23\u0e19\u0e33\u0e23\u0e48\u0e2d\u0e07 AI \u0e04\u0e27\u0e1a\u0e04\u0e38\u0e21\u0e2a\u0e31\u0e0d\u0e0d\u0e32\u0e13\u0e44\u0e1f\u0e08\u0e23\u0e32\u0e08\u0e23\u0e41\u0e25\u0e49\u0e27 74 \u0e41\u0e22\u0e01",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/bma-ai-traffic-control-bangkok.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "3 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e40\u0e21\u0e37\u0e2d\u0e07",
    readTime: "4 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "alcohol",
    category: "THAILAND",
    title: "\u0e2a\u0e18.-\u0e2a\u0e27\u0e23\u0e2a. \u0e01\u0e32\u0e07\u0e1c\u0e25\u0e27\u0e34\u0e08\u0e31\u0e22 2 \u0e40\u0e14\u0e37\u0e2d\u0e19\u0e41\u0e23\u0e01\u0e1b\u0e25\u0e14\u0e25\u0e47\u0e2d\u0e01\u0e40\u0e27\u0e25\u0e32\u0e02\u0e32\u0e22\u0e2a\u0e38\u0e23\u0e32 \u0e1e\u0e1a\u0e23\u0e49\u0e32\u0e19\u0e2d\u0e32\u0e2b\u0e32\u0e23\u0e22\u0e2d\u0e14\u0e1e\u0e38\u0e48\u0e07 \u0e41\u0e15\u0e48\u0e20\u0e32\u0e1e\u0e23\u0e27\u0e21\u0e40\u0e28\u0e23\u0e29\u0e10\u0e01\u0e34\u0e08\u0e22\u0e31\u0e07\u0e17\u0e23\u0e07\u0e15\u0e31\u0e27",
    excerpt: "\u0e1c\u0e25\u0e27\u0e34\u0e08\u0e31\u0e22\u0e2b\u0e25\u0e31\u0e07\u0e1b\u0e25\u0e14\u0e25\u0e47\u0e2d\u0e01\u0e40\u0e27\u0e25\u0e32\u0e02\u0e32\u0e22\u0e2a\u0e38\u0e23\u0e32 2 \u0e40\u0e14\u0e37\u0e2d\u0e19\u0e41\u0e23\u0e01 \u0e0a\u0e35\u0e49\u0e23\u0e49\u0e32\u0e19\u0e2d\u0e32\u0e2b\u0e32\u0e23\u0e22\u0e2d\u0e14\u0e02\u0e32\u0e22\u0e40\u0e1e\u0e34\u0e48\u0e21",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/alcohol-sales-research-economy.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "4 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e2a\u0e38\u0e02\u0e20\u0e32\u0e1e",
    readTime: "5 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "taliban",
    category: "WORLD",
    title: "\u0e15\u0e32\u0e25\u0e35\u0e1a\u0e31\u0e19\u0e2d\u0e2d\u0e01\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22 \u0e40\u0e1b\u0e34\u0e14\u0e17\u0e32\u0e07\u0e2a\u0e32\u0e21\u0e35\u0e25\u0e07\u0e42\u0e17\u0e29\u0e20\u0e23\u0e23\u0e22\u0e32\u0e41\u0e25\u0e30\u0e1a\u0e38\u0e15\u0e23 \u0e2b\u0e32\u0e01\u0e44\u0e21\u0e48\u0e16\u0e36\u0e07\u0e02\u0e31\u0e49\u0e19 \u2018\u0e01\u0e23\u0e30\u0e14\u0e39\u0e01\u0e2b\u0e31\u0e01\u2019 \u0e2b\u0e23\u0e37\u0e2d \u2018\u0e41\u0e1c\u0e25\u0e40\u0e1b\u0e34\u0e14\u2019",
    excerpt: "\u0e23\u0e31\u0e10\u0e1a\u0e32\u0e25\u0e15\u0e32\u0e25\u0e35\u0e1a\u0e31\u0e19\u0e43\u0e19\u0e2d\u0e31\u0e1f\u0e01\u0e32\u0e19\u0e34\u0e2a\u0e16\u0e32\u0e19\u0e2d\u0e2d\u0e01\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22\u0e43\u0e2b\u0e21\u0e48\u0e43\u0e2b\u0e49\u0e2d\u0e33\u0e19\u0e32\u0e08\u0e2a\u0e32\u0e21\u0e35\u0e25\u0e07\u0e42\u0e17\u0e29\u0e20\u0e23\u0e23\u0e22\u0e32\u0e41\u0e25\u0e30\u0e1a\u0e38\u0e15\u0e23\u0e44\u0e14\u0e49\u0e43\u0e19\u0e01\u0e23\u0e2d\u0e1a\u0e17\u0e35\u0e48\u0e01\u0e33\u0e2b\u0e19\u0e14",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/talibanhusbandfamilypunishment.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "5 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e15\u0e48\u0e32\u0e07\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28",
    readTime: "7 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "adecco",
    category: "BUSINESS",
    title: "\u0e16\u0e2d\u0e14\u0e23\u0e2b\u0e31\u0e2a\u0e42\u0e25\u0e01\u0e41\u0e23\u0e07\u0e07\u0e32\u0e19\u0e1b\u0e35 2026 \u2018\u0e40\u0e21\u0e37\u0e48\u0e2d AI \u0e44\u0e21\u0e48\u0e43\u0e0a\u0e48\u0e1c\u0e39\u0e49\u0e23\u0e49\u0e32\u0e22 \u0e41\u0e15\u0e48\u0e04\u0e27\u0e32\u0e21\u0e25\u0e31\u0e07\u0e40\u0e25\u0e04\u0e37\u0e2d\u0e28\u0e31\u0e15\u0e23\u0e39\u0e17\u0e35\u0e48\u0e41\u0e17\u0e49\u0e08\u0e23\u0e34\u0e07\u2019 \u0e01\u0e31\u0e1a Denis Machuel \u0e0b\u0e35\u0e2d\u0e42\u0e2d The Adecco Group",
    excerpt: "\u0e1a\u0e17\u0e2a\u0e19\u0e17\u0e19\u0e32\u0e01\u0e31\u0e1a Denis Machuel \u0e0b\u0e35\u0e2d\u0e42\u0e2d The Adecco Group \u0e27\u0e48\u0e32\u0e14\u0e49\u0e27\u0e22\u0e2d\u0e19\u0e32\u0e04\u0e15\u0e41\u0e23\u0e07\u0e07\u0e32\u0e19 \u0e17\u0e31\u0e01\u0e29\u0e30\u0e43\u0e2b\u0e21\u0e48 \u0e41\u0e25\u0e30\u0e1a\u0e17\u0e1a\u0e32\u0e17 AI \u0e43\u0e19\u0e15\u0e25\u0e32\u0e14\u0e07\u0e32\u0e19\u0e42\u0e25\u0e01",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/denis-machuel-adecco-future-of-work-ai-2026.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "6 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "THE SECRET SAUCE",
    readTime: "8 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "empowerher",
    category: "BUSINESS",
    title: "\u0e15\u0e49\u0e2d\u0e19\u0e23\u0e31\u0e1a\u0e27\u0e31\u0e19\u0e2a\u0e15\u0e23\u0e35\u0e2a\u0e32\u0e01\u0e25! The CrestHaus \u0e08\u0e31\u0e14\u0e43\u0e2b\u0e0d\u0e48 \u0e14\u0e36\u0e07\u0e2a\u0e38\u0e14\u0e22\u0e2d\u0e14\u0e1c\u0e39\u0e49\u0e19\u0e33\u0e2b\u0e0d\u0e34\u0e07\u0e40\u0e2d\u0e40\u0e0a\u0e35\u0e22 \u0e23\u0e48\u0e27\u0e21\u0e41\u0e0a\u0e23\u0e4c\u0e01\u0e25\u0e22\u0e38\u0e17\u0e18\u0e4c Write Your Next Chapter",
    excerpt: "\u0e40\u0e27\u0e17\u0e35 EmpowerHER Asia Leadership Forum \u0e23\u0e27\u0e21\u0e1c\u0e39\u0e49\u0e19\u0e33\u0e2b\u0e0d\u0e34\u0e07\u0e23\u0e30\u0e14\u0e31\u0e1a\u0e40\u0e2d\u0e40\u0e0a\u0e35\u0e22\u0e23\u0e48\u0e27\u0e21\u0e16\u0e48\u0e32\u0e22\u0e17\u0e2d\u0e14\u0e1b\u0e23\u0e30\u0e2a\u0e1a\u0e01\u0e32\u0e23\u0e13\u0e4c\u0e41\u0e25\u0e30\u0e01\u0e25\u0e22\u0e38\u0e17\u0e18\u0e4c",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/empowerher-asia-leadership-forum.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "7 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08",
    readTime: "5 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "on-italy",
    category: "SPORT",
    title: "On \u0e08\u0e31\u0e1a\u0e21\u0e37\u0e2d\u0e17\u0e35\u0e21\u0e01\u0e23\u0e35\u0e11\u0e32\u0e2d\u0e34\u0e15\u0e32\u0e25\u0e35 \u0e40\u0e1b\u0e34\u0e14\u0e15\u0e31\u0e27\u0e0a\u0e38\u0e14\u0e17\u0e35\u0e21\u0e0a\u0e32\u0e15\u0e34\u0e22\u0e38\u0e04\u0e43\u0e2b\u0e21\u0e48",
    excerpt: "\u0e41\u0e1a\u0e23\u0e19\u0e14\u0e4c\u0e2a\u0e27\u0e34\u0e2a On \u0e1b\u0e23\u0e30\u0e01\u0e32\u0e28\u0e04\u0e27\u0e32\u0e21\u0e23\u0e48\u0e27\u0e21\u0e21\u0e37\u0e2d\u0e17\u0e35\u0e21\u0e01\u0e23\u0e35\u0e11\u0e32\u0e2d\u0e34\u0e15\u0e32\u0e25\u0e35 \u0e40\u0e1b\u0e34\u0e14\u0e15\u0e31\u0e27\u0e0a\u0e38\u0e14\u0e41\u0e02\u0e48\u0e07\u0e22\u0e38\u0e04\u0e43\u0e2b\u0e21\u0e48",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/on-italian-athletics-kit.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "8 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e01\u0e35\u0e2c\u0e32",
    readTime: "3 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "scbx",
    category: "BUSINESS",
    title: "SCBX \u0e15\u0e34\u0e14 Top 10 \u0e41\u0e1a\u0e07\u0e01\u0e4c\u0e22\u0e31\u0e48\u0e07\u0e22\u0e37\u0e19 S&P Global 2026 \u0e04\u0e23\u0e2d\u0e07\u0e2d\u0e31\u0e19\u0e14\u0e31\u0e1a 1 \u0e43\u0e19\u0e44\u0e17\u0e22",
    excerpt: "SCBX \u0e44\u0e14\u0e49\u0e23\u0e31\u0e1a\u0e01\u0e32\u0e23\u0e08\u0e31\u0e14\u0e2d\u0e31\u0e19\u0e14\u0e31\u0e1a\u0e15\u0e34\u0e14 Top 10 \u0e18\u0e19\u0e32\u0e04\u0e32\u0e23\u0e22\u0e31\u0e48\u0e07\u0e22\u0e37\u0e19\u0e23\u0e30\u0e14\u0e31\u0e1a\u0e42\u0e25\u0e01\u0e08\u0e32\u0e01 S&P Global",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/scbxtopsustainablebankglobal.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "9 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08",
    readTime: "4 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "thai-union",
    category: "BUSINESS",
    title: "\u0e44\u0e17\u0e22\u0e22\u0e39\u0e40\u0e19\u0e35\u0e48\u0e22\u0e19 \u0e01\u0e23\u0e38\u0e4a\u0e1b\u0e2f \u0e1b\u0e35 68 \u0e01\u0e27\u0e32\u0e14\u0e22\u0e2d\u0e14\u0e02\u0e32\u0e22\u0e17\u0e30\u0e25\u0e38 1.3 \u0e41\u0e2a\u0e19\u0e25\u0e49\u0e32\u0e19 \u0e1b\u0e35 69 \u0e15\u0e31\u0e49\u0e07\u0e40\u0e1b\u0e49\u0e32\u0e42\u0e15 3-4%",
    excerpt: "\u0e44\u0e17\u0e22\u0e22\u0e39\u0e40\u0e19\u0e35\u0e48\u0e22\u0e19 \u0e01\u0e23\u0e38\u0e4a\u0e1b \u0e40\u0e1b\u0e34\u0e14\u0e1c\u0e25\u0e1b\u0e23\u0e30\u0e01\u0e2d\u0e1a\u0e01\u0e32\u0e23\u0e1b\u0e35 68 \u0e22\u0e2d\u0e14\u0e02\u0e32\u0e22\u0e17\u0e30\u0e25\u0e38 1.3 \u0e41\u0e2a\u0e19\u0e25\u0e49\u0e32\u0e19",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/thai-union-sales-dividend-2025-outlook.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "10 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e18\u0e38\u0e23\u0e01\u0e34\u0e08",
    readTime: "5 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "zuckerberg",
    category: "TECH",
    title: "\u0e0b\u0e31\u0e01\u0e40\u0e04\u0e2d\u0e23\u0e4c\u0e40\u0e1a\u0e34\u0e23\u0e4c\u0e01\u0e02\u0e36\u0e49\u0e19\u0e43\u0e2b\u0e49\u0e01\u0e32\u0e23\u0e04\u0e14\u0e35\u0e1b\u0e23\u0e30\u0e27\u0e31\u0e15\u0e34\u0e28\u0e32\u0e2a\u0e15\u0e23\u0e4c \u0e16\u0e39\u0e01\u0e1f\u0e49\u0e2d\u0e07\u0e27\u0e48\u0e32\u0e08\u0e07\u0e43\u0e08\u0e2d\u0e2d\u0e01\u0e41\u0e1a\u0e1a\u0e41\u0e2d\u0e1b\u0e43\u0e2b\u0e49\u0e40\u0e14\u0e47\u0e01\u0e40\u0e2a\u0e1e\u0e15\u0e34\u0e14",
    excerpt: "\u0e0b\u0e35\u0e2d\u0e42\u0e2d Meta \u0e02\u0e36\u0e49\u0e19\u0e28\u0e32\u0e25\u0e43\u0e19\u0e04\u0e14\u0e35\u0e1b\u0e23\u0e30\u0e27\u0e31\u0e15\u0e34\u0e28\u0e32\u0e2a\u0e15\u0e23\u0e4c \u0e16\u0e39\u0e01\u0e01\u0e25\u0e48\u0e32\u0e27\u0e2b\u0e32\u0e08\u0e07\u0e43\u0e08\u0e2d\u0e2d\u0e01\u0e41\u0e1a\u0e1a\u0e41\u0e2d\u0e1b\u0e43\u0e2b\u0e49\u0e40\u0e14\u0e47\u0e01\u0e40\u0e2a\u0e1e\u0e15\u0e34\u0e14",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/zuckerbergsocialmediaaddictionlawsuitkids.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "11 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35",
    readTime: "6 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "google-io",
    category: "TECH",
    title: "Google I/O 2026 \u0e27\u0e31\u0e19\u0e17\u0e35\u0e48 19-20 \u0e1e\u0e24\u0e29\u0e20\u0e32\u0e04\u0e21 \u0e08\u0e31\u0e1a\u0e15\u0e32 AI Gemini \u0e41\u0e25\u0e30 Android",
    excerpt: "Google \u0e1b\u0e23\u0e30\u0e01\u0e32\u0e28\u0e01\u0e33\u0e2b\u0e19\u0e14\u0e01\u0e32\u0e23 I/O 2026 \u0e27\u0e31\u0e19\u0e17\u0e35\u0e48 19-20 \u0e1e\u0e24\u0e29\u0e20\u0e32\u0e04\u0e21 \u0e08\u0e31\u0e1a\u0e15\u0e32\u0e01\u0e32\u0e23\u0e40\u0e1b\u0e34\u0e14\u0e15\u0e31\u0e27 AI Gemini \u0e23\u0e38\u0e48\u0e19\u0e43\u0e2b\u0e21\u0e48",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/google-io-2026-ai-gemini-android.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "12 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35",
    readTime: "4 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "f1-imax",
    category: "SPORT",
    title: "F1 2026 \u0e16\u0e48\u0e32\u0e22\u0e17\u0e2d\u0e14\u0e2a\u0e14\u0e1c\u0e48\u0e32\u0e19\u0e08\u0e2d Imax \u0e17\u0e31\u0e48\u0e27\u0e2a\u0e2b\u0e23\u0e31\u0e10\u0e2f",
    excerpt: "\u0e24\u0e14\u0e39\u0e01\u0e32\u0e25 F1 2026 \u0e40\u0e15\u0e23\u0e35\u0e22\u0e21\u0e16\u0e48\u0e32\u0e22\u0e17\u0e2d\u0e14\u0e2a\u0e14\u0e1c\u0e48\u0e32\u0e19\u0e08\u0e2d Imax \u0e17\u0e31\u0e48\u0e27\u0e2d\u0e40\u0e21\u0e23\u0e34\u0e01\u0e32",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/f12026imaxuslive.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "14 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e01\u0e35\u0e2c\u0e32",
    readTime: "3 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "alysa-liu",
    category: "SPORT",
    title: "Alysa Liu \u0e01\u0e32\u0e23\u0e01\u0e25\u0e31\u0e1a\u0e21\u0e32\u0e02\u0e2d\u0e07\u0e2a\u0e32\u0e27\u0e19\u0e49\u0e2d\u0e22\u0e21\u0e2b\u0e31\u0e28\u0e08\u0e23\u0e23\u0e22\u0e4c \u0e01\u0e31\u0e1a\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e43\u0e2b\u0e49 \u2018\u0e04\u0e27\u0e32\u0e21\u0e2a\u0e38\u0e02\u2019 \u0e19\u0e33\u0e17\u0e32\u0e07\u0e2a\u0e39\u0e48\u0e40\u0e2b\u0e23\u0e35\u0e22\u0e0d\u0e17\u0e2d\u0e07\u0e42\u0e2d\u0e25\u0e34\u0e21\u0e1b\u0e34\u0e01",
    excerpt: "\u0e40\u0e23\u0e37\u0e48\u0e2d\u0e07\u0e23\u0e32\u0e27\u0e01\u0e32\u0e23\u0e04\u0e31\u0e21\u0e41\u0e1a\u0e04\u0e4c\u0e02\u0e2d\u0e07 Alysa Liu \u0e19\u0e31\u0e01\u0e2a\u0e40\u0e01\u0e15\u0e25\u0e35\u0e25\u0e32\u0e14\u0e32\u0e27\u0e23\u0e38\u0e48\u0e07 \u0e01\u0e31\u0e1a\u0e40\u0e2b\u0e23\u0e35\u0e22\u0e0d\u0e17\u0e2d\u0e07\u0e42\u0e2d\u0e25\u0e34\u0e21\u0e1b\u0e34\u0e01",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/alysa-liu-olympic-gold.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "16 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e01\u0e35\u0e2c\u0e32",
    readTime: "6 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "imf-china",
    category: "WORLD",
    title: "IMF \u0e40\u0e15\u0e37\u0e2d\u0e19\u0e08\u0e35\u0e19 \u0e1c\u0e25\u0e34\u0e15\u0e25\u0e49\u0e19-\u0e2a\u0e48\u0e07\u0e2d\u0e2d\u0e01\u0e2a\u0e39\u0e07 \u0e17\u0e33\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28\u0e04\u0e39\u0e48\u0e04\u0e49\u0e32\u0e40\u0e2a\u0e35\u0e22\u0e2b\u0e32\u0e22 \u0e41\u0e19\u0e30\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e2d\u0e38\u0e1b\u0e2a\u0e07\u0e04\u0e4c\u0e43\u0e19\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28",
    excerpt: "IMF \u0e2d\u0e2d\u0e01\u0e23\u0e32\u0e22\u0e07\u0e32\u0e19\u0e40\u0e15\u0e37\u0e2d\u0e19\u0e08\u0e35\u0e19 \u0e1b\u0e31\u0e0d\u0e2b\u0e32\u0e1c\u0e25\u0e34\u0e15\u0e40\u0e01\u0e34\u0e19\u0e41\u0e25\u0e30\u0e2a\u0e48\u0e07\u0e2d\u0e2d\u0e01\u0e2a\u0e39\u0e07\u0e01\u0e23\u0e30\u0e17\u0e1a\u0e04\u0e39\u0e48\u0e04\u0e49\u0e32",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/imfchinaoverproductionexportswarning.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "18 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e15\u0e48\u0e32\u0e07\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28",
    readTime: "5 \u0e19\u0e32\u0e17\u0e35"
  },
  {
    id: "us-indonesia",
    category: "WORLD",
    title: "\u0e2a\u0e2b\u0e23\u0e31\u0e10\u0e2f-\u0e2d\u0e34\u0e19\u0e42\u0e14\u0e19\u0e35\u0e40\u0e0b\u0e35\u0e22 \u0e1a\u0e23\u0e23\u0e25\u0e38\u0e02\u0e49\u0e2d\u0e15\u0e01\u0e25\u0e07\u0e01\u0e32\u0e23\u0e04\u0e49\u0e32 \u0e25\u0e14\u0e20\u0e32\u0e29\u0e35\u0e19\u0e33\u0e40\u0e02\u0e49\u0e32\u0e40\u0e2b\u0e25\u0e37\u0e2d 19%",
    excerpt: "\u0e2a\u0e2b\u0e23\u0e31\u0e10\u0e2f \u0e41\u0e25\u0e30\u0e2d\u0e34\u0e19\u0e42\u0e14\u0e19\u0e35\u0e40\u0e0b\u0e35\u0e22\u0e1b\u0e23\u0e30\u0e01\u0e32\u0e28\u0e1a\u0e23\u0e23\u0e25\u0e38\u0e02\u0e49\u0e2d\u0e15\u0e01\u0e25\u0e07\u0e01\u0e32\u0e23\u0e04\u0e49\u0e32\u0e04\u0e23\u0e31\u0e49\u0e07\u0e2a\u0e33\u0e04\u0e31\u0e0d",
    image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/cover-web-2-1.jpg&w=1200&h=628&fit=cover&output=jpg&q=82",
    time: "20 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27",
    author: "\u0e17\u0e35\u0e21\u0e02\u0e48\u0e32\u0e27\u0e15\u0e48\u0e32\u0e07\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28",
    readTime: "4 \u0e19\u0e32\u0e17\u0e35"
  }
];

window.POPULAR = [
  { rank: 1, id: "pop-1", articleId: "zuckerberg", cat: "TECH", title: "\u0e0b\u0e31\u0e01\u0e40\u0e04\u0e2d\u0e23\u0e4c\u0e40\u0e1a\u0e34\u0e23\u0e4c\u0e01\u0e02\u0e36\u0e49\u0e19\u0e43\u0e2b\u0e49\u0e01\u0e32\u0e23\u0e04\u0e14\u0e35\u0e1b\u0e23\u0e30\u0e27\u0e31\u0e15\u0e34\u0e28\u0e32\u0e2a\u0e15\u0e23\u0e4c \u0e16\u0e39\u0e01\u0e1f\u0e49\u0e2d\u0e07\u0e27\u0e48\u0e32\u0e08\u0e07\u0e43\u0e08\u0e2d\u0e2d\u0e01\u0e41\u0e1a\u0e1a\u0e41\u0e2d\u0e1b\u0e43\u0e2b\u0e49\u0e40\u0e14\u0e47\u0e01\u0e40\u0e2a\u0e1e\u0e15\u0e34\u0e14", views: "142,308", time: "11 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27", image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/zuckerbergsocialmediaaddictionlawsuitkids.jpg&w=1200&h=628&fit=cover&output=jpg&q=82" },
  { rank: 2, id: "pop-2", articleId: "raab-11", cat: "POLITICS", title: "\u0e28\u0e32\u0e25\u0e2d\u0e32\u0e0d\u0e32\u0e1e\u0e34\u0e1e\u0e32\u0e01\u0e29\u0e32\u0e08\u0e33\u0e04\u0e38\u0e01 4 \u0e41\u0e01\u0e19\u0e19\u0e33\u0e04\u0e14\u0e35\u0e0a\u0e38\u0e21\u0e19\u0e38\u0e21\u0e23\u0e32\u0e1a 11 \u0e04\u0e19\u0e25\u0e30 2 \u0e1b\u0e35 8 \u0e40\u0e14\u0e37\u0e2d\u0e19", views: "98,441", time: "34 \u0e19\u0e32\u0e17\u0e35\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27", image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/raab-11-leaders-jailed.jpg&w=1200&h=628&fit=cover&output=jpg&q=82" },
  { rank: 3, id: "pop-3", articleId: "taliban", cat: "WORLD", title: "\u0e15\u0e32\u0e25\u0e35\u0e1a\u0e31\u0e19\u0e2d\u0e2d\u0e01\u0e01\u0e0e\u0e2b\u0e21\u0e32\u0e22\u0e40\u0e1b\u0e34\u0e14\u0e17\u0e32\u0e07\u0e2a\u0e32\u0e21\u0e35\u0e25\u0e07\u0e42\u0e17\u0e29\u0e20\u0e23\u0e23\u0e22\u0e32\u0e41\u0e25\u0e30\u0e1a\u0e38\u0e15\u0e23", views: "87,120", time: "5 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27", image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/talibanhusbandfamilypunishment.jpg&w=1200&h=628&fit=cover&output=jpg&q=82" },
  { rank: 4, id: "pop-4", articleId: "adecco", cat: "BUSINESS", title: "\u0e16\u0e2d\u0e14\u0e23\u0e2b\u0e31\u0e2a\u0e42\u0e25\u0e01\u0e41\u0e23\u0e07\u0e07\u0e32\u0e19\u0e1b\u0e35 2026 \u0e40\u0e21\u0e37\u0e48\u0e2d AI \u0e44\u0e21\u0e48\u0e43\u0e0a\u0e48\u0e1c\u0e39\u0e49\u0e23\u0e49\u0e32\u0e22 \u0e41\u0e15\u0e48\u0e04\u0e27\u0e32\u0e21\u0e25\u0e31\u0e07\u0e40\u0e25\u0e04\u0e37\u0e2d\u0e28\u0e31\u0e15\u0e23\u0e39\u0e17\u0e35\u0e48\u0e41\u0e17\u0e49\u0e08\u0e23\u0e34\u0e07", views: "73,895", time: "6 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27", image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/denis-machuel-adecco-future-of-work-ai-2026.jpg&w=1200&h=628&fit=cover&output=jpg&q=82" },
  { rank: 5, id: "pop-5", articleId: "ai-traffic", cat: "THAILAND", title: "\u0e01\u0e17\u0e21. \u0e15\u0e34\u0e14\u0e01\u0e25\u0e49\u0e2d\u0e07 AI \u0e04\u0e38\u0e21\u0e41\u0e22\u0e01\u0e08\u0e23\u0e32\u0e08\u0e23 74 \u0e08\u0e38\u0e14\u0e17\u0e31\u0e48\u0e27\u0e01\u0e23\u0e38\u0e07 \u0e40\u0e15\u0e23\u0e35\u0e22\u0e21\u0e02\u0e22\u0e32\u0e22\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e2d\u0e35\u0e01 50 \u0e41\u0e22\u0e01\u0e1b\u0e35\u0e19\u0e35\u0e49", views: "61,207", time: "3 \u0e0a\u0e31\u0e48\u0e27\u0e42\u0e21\u0e07\u0e17\u0e35\u0e48\u0e41\u0e25\u0e49\u0e27", image: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2026/02/bma-ai-traffic-control-bangkok.jpg&w=1200&h=628&fit=cover&output=jpg&q=82" }
];

window.EVENTS = [
  {
    id: "isaan-2026",
    tag: "THE SECRET SAUCE",
    series: "BUSINESS WEEKEND",
    title: "อีสาน 2026",
    subtitle: "เทศกาลผู้ประกอบการที่ม่วนที่สุดในอีสาน กลับมาแล้ว!",
    date: "18 กรกฎาคม 2569",
    venue: "KICE Khonkaen",
    ticketDate: "จำหน่ายบัตรวันแรก 27 เม.ย. ที่ Zipevent",
    cta: "จองบัตรเลย",
    accent: "#e62227",
    textColor: "#f5f01a",
    image: (window.TS_THEME_URI||"") + "/assets/images/event-isaan-2026.png",
    featured: true
  },
];

window.TICKER_ITEMS = [
  { cat: "BREAKING", text: "\u0e28\u0e32\u0e25\u0e2d\u0e32\u0e0d\u0e32\u0e1e\u0e34\u0e1e\u0e32\u0e01\u0e29\u0e32\u0e08\u0e33\u0e04\u0e38\u0e01 4 \u0e41\u0e01\u0e19\u0e19\u0e33\u0e04\u0e14\u0e35\u0e0a\u0e38\u0e21\u0e19\u0e38\u0e21\u0e23\u0e32\u0e1a 11" },
  { cat: "MARKET",   text: "SET +0.82% \u00b7 USD/THB 35.42 \u00b7 \u0e17\u0e2d\u0e07\u0e04\u0e33 2,032.50 \u00b7 BTC $67,840" },
  { cat: "POLITICS", text: "\u0e2a\u0e27. \u0e40\u0e1b\u0e34\u0e14\u0e1e\u0e37\u0e49\u0e19\u0e17\u0e35\u0e48\u0e16\u0e01\u0e1b\u0e21\u0e1b\u0e23\u0e30\u0e01\u0e31\u0e19\u0e2a\u0e31\u0e07\u0e04\u0e21 \u0e0a\u0e35\u0e49\u0e40\u0e2b\u0e15\u0e38\u0e1c\u0e25\u0e1b\u0e23\u0e30\u0e0a\u0e32\u0e1e\u0e34\u0e08\u0e32\u0e23\u0e13\u0e4c\u0e25\u0e48\u0e32\u0e0a\u0e49\u0e32" },
  { cat: "WORLD",    text: "\u0e2a\u0e2b\u0e23\u0e31\u0e10\u0e2f-\u0e2d\u0e34\u0e19\u0e42\u0e14\u0e19\u0e35\u0e40\u0e0b\u0e35\u0e22 \u0e1a\u0e23\u0e23\u0e25\u0e38\u0e02\u0e49\u0e2d\u0e15\u0e01\u0e25\u0e07\u0e01\u0e32\u0e23\u0e04\u0e49\u0e32 \u0e25\u0e14\u0e20\u0e32\u0e29\u0e35\u0e40\u0e2b\u0e25\u0e37\u0e2d 19%" },
  { cat: "TECH",     text: "Google I/O 2026 \u0e1b\u0e31\u0e01\u0e2b\u0e21\u0e38\u0e14 19-20 \u0e1e.\u0e04. \u0e08\u0e31\u0e1a\u0e15\u0e32 AI Gemini" }
];

window.CATEGORIES = ["ALL", "POLITICS", "BUSINESS", "THAILAND", "WORLD", "TECH", "SPORT"];

window.NAV_ITEMS = [
  { label: "HOME",             cat: null,       mega: null },
  { label: "NEWS",             cat: null,       mega: "NEWS" },
  { label: "WEALTH",           cat: "BUSINESS", mega: "WEALTH" },
  { label: "POP",              cat: null,       mega: "POP" },
  { label: "LIFE",             cat: null,       mega: "LIFE" },
  { label: "THE SECRET SAUCE", cat: null,       mega: null },
  { label: "OPINION",          cat: null,       mega: null },
  { label: "EVENTS",           cat: null,       mega: null },
  { label: "CAREERS",          cat: null,       mega: null },
  { label: "ABOUT",            cat: null,       mega: null }
];

window.MEGA_MENU = {
  WEALTH: { label: "WEALTH", color: "#c19380", topics: [
    "ECONOMIC", "MARKET", "BUSINESS", "CRYPTOCURRENCY", "OPINION",
    "PERSONAL FINANCE", "WEALTH MANAGEMENT", "WORK & LEADERSHIP", "LIFESTYLE & PASSION"
  ]},
  NEWS: { label: "NEWS", color: "#e62227", topics: [
    "Global Edition","Politics","Business","Thailand","World",
    "Mobility","Semiconductor","Energy Transition","Cost of Living",
    "Tech","Sport","Environment","LGBTQIA+","Science","China","On This Day"
  ]},
  POP: { label: "POP", color: "#0000ff", topics: [
    "Entertainment","Film","Music","Fashion","K-POP","Art & Design"
  ]},
  LIFE: { label: "LIFE", color: "#000000", topics: [
    "Food & Drink","Place","Active Leisure","Body & Mind","Living","Tech & Gadget"
  ]},
  POLITICS: { label: "การเมือง", color: "#E6332A", topics: ["เลือกตั้ง 2569","รัฐสภา","นโยบายรัฐ","พรรคการเมือง","การกระจายอำนาจ","ความมั่นคง"] },
  BUSINESS: { label: "ธุรกิจ", color: "#2A6FDB",  topics: ["ตลาดทุน","เศรษฐกิจมหภาค","สตาร์ทอัพ","อสังหาริมทรัพย์","การลงทุน","แรงงาน"] },
  THAILAND: { label: "ในประเทศ", color: "#E6332A", topics: ["สังคม","อาชญากรรม","สิ่งแวดล้อม","การศึกษา","สาธารณสุข","เมือง"] },
  WORLD:    { label: "ต่างประเทศ", color: "#2A6FDB", topics: ["เอเชีย","สหรัฐฯ","ยุโรป","ตะวันออกกลาง","ภูมิรัฐศาสตร์","การค้าโลก"] },
  TECH:     { label: "เทคโนโลยี", color: "#0f4c81", topics: ["AI","แกดเจ็ต","อินเทอร์เน็ต","ความเป็นส่วนตัว","แพลตฟอร์ม","นวัตกรรม"] },
  SPORT:    { label: "กีฬา", color: "#1F8A5B",  topics: ["ฟุตบอล","โอลิมปิก","มอเตอร์สปอร์ต","เทนนิส","อีสปอร์ต","กีฬาไทย"] }
};

window.VERTICALS = [
  { name: "WEALTH",           desc: "การเงิน-การลงทุน" },
  { name: "POP",              desc: "วัฒนธรรม-บันเทิง" },
  { name: "LIFE",             desc: "ไลฟ์สไตล์-สุขภาพ" },
  { name: "THE SECRET SAUCE", desc: "ธุรกิจ-พอดแคสต์" }
];

window.OPINIONS = [
  {
    id: "op-de-influencing",
    columnist: "THE SECRET SAUCE",
    tag: "สื่อ-การตลาด",
    avatar: "https://ui-avatars.com/api/?name=TSS&background=1f1f1f&color=e6332a&size=128&bold=true&font-size=0.4",
    title: "เทรนด์ De-Influencing: จุดจบ Influencer สายป้ายยาขายฝัน เมื่อผู้บริโภคขอแบนโฆษณาจัดฉากเกินจริง",
    excerpt: "เมื่อความจริงแพงกว่าความฝัน คนดูเริ่มตั้งคำถามว่าสิ่งที่อินฟลูเอนเซอร์ขายนั้น ดีพอสำหรับชีวิตจริงหรือเปล่า",
    time: "2 ชั่วโมงที่แล้ว",
    readTime: "8 นาที"
  },
  {
    id: "op-china-university",
    columnist: "THE SECRET SAUCE",
    tag: "นโยบาย-การศึกษา",
    avatar: "https://ui-avatars.com/api/?name=TSS&background=1f1f1f&color=e6332a&size=128&bold=true&font-size=0.4",
    title: "จีนเปิด 38 วิชาใหม่ระดับมหาลัย แผนสร้างชาติที่คนธรรมดาต้องรู้ให้ทัน",
    excerpt: "วิชาที่จีนเลือกเปิดสอนบอกทิศทางประเทศ และทำไมนักศึกษาในที่อื่นควรจับตาดูให้ดี",
    time: "4 ชั่วโมงที่แล้ว",
    readTime: "6 นาที"
  },
  {
    id: "op-gold",
    columnist: "ฐิภา นววัฒนทรัพย์",
    tag: "การลงทุน",
    avatar: "https://ui-avatars.com/api/?name=ฐน&background=1f1f1f&color=e6332a&size=128&bold=true&font-size=0.45",
    title: "แรงซื้อทองคำยังแน่น ไม่ยอมให้เข้าสู่ Bear Market",
    excerpt: "เมื่อความไม่แน่นอนของโลกยังสูง ทองคำจึงไม่ใช่แค่ของสะสม แต่คือเกราะป้องกันที่นักลงทุนยังเชื่อถือ",
    time: "1 วันที่แล้ว",
    readTime: "5 นาที"
  },
  {
    id: "op-ev",
    columnist: "THE STANDARD OPINION",
    tag: "สิ่งแวดล้อม-พลังงาน",
    avatar: "https://ui-avatars.com/api/?name=TSO&background=1f1f1f&color=e6332a&size=128&bold=true&font-size=0.4",
    title: "EV ไม่ใช่แค่เรื่องสิ่งแวดล้อม แต่อาจเป็นทางรอดด้านพลังงานของอาเซียน",
    excerpt: "การเปลี่ยนผ่านสู่ยานยนต์ไฟฟ้าในอาเซียนไม่ใช่แค่ลดคาร์บอน แต่คือโอกาสหลุดพ้นจากการพึ่งพาน้ำมันนำเข้า",
    time: "1 วันที่แล้ว",
    readTime: "7 นาที"
  }
];

// ── VIDEOS ──────────────────────────────────────────────────────────────────
window.VIDEOS = [
  {
    id: "v-ai-war",
    title: "สงคราม AI: เมื่อ OpenAI, Google และ Meta แข่งกันสร้างโมเดลที่ฉลาดที่สุดในโลก",
    channel: "THE STANDARD",
    duration: "18:42",
    views: "128K",
    time: "2 วันที่แล้ว",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/aircAruvnKk/maxresdefault.jpg&w=800&h=450&fit=cover&output=jpg&q=82",
    url: "https://www.youtube.com/@TheStandardCo"
  },
  {
    id: "v-election",
    title: "เลือกตั้ง 2569: ทุกพรรคเสนออะไร แล้วประชาชนได้อะไรจริงๆ",
    channel: "THE STANDARD",
    duration: "24:17",
    views: "89K",
    time: "3 วันที่แล้ว",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/LXb3EKWsInQ/maxresdefault.jpg&w=800&h=450&fit=cover&output=jpg&q=82",
    url: "https://www.youtube.com/@TheStandardCo"
  },
  {
    id: "v-economy",
    title: "เศรษฐกิจไทยหลัง Q1/2569 ดีขึ้นหรือแย่ลง? เปิดตัวเลข GDP ล่าสุด",
    channel: "THE STANDARD WEALTH",
    duration: "12:05",
    views: "54K",
    time: "4 วันที่แล้ว",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/dQw4w9WgXcQ/maxresdefault.jpg&w=800&h=450&fit=cover&output=jpg&q=82",
    url: "https://www.youtube.com/@TheStandardCo"
  },
  {
    id: "v-crypto",
    title: "Crypto ในยุค Regulation: นักลงทุนไทยต้องรู้อะไรบ้าง",
    channel: "THE STANDARD WEALTH",
    duration: "09:33",
    views: "41K",
    time: "5 วันที่แล้ว",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/ZZ5LpwO-An4/maxresdefault.jpg&w=800&h=450&fit=cover&output=jpg&q=82",
    url: "https://www.youtube.com/@TheStandardCo"
  }
];

// ── SHORT CLIPS ──────────────────────────────────────────────────────────────
window.SHORT_CLIPS = [
  {
    id: "s-tariff",
    title: "ทำไมภาษีนำเข้าสหรัฐฯ ถึงกระทบราคาสินค้าในไทย",
    duration: "0:58",
    tag: "#SHORTS",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/PkZNo7MFNFg/hqdefault.jpg&w=360&h=640&fit=cover&output=jpg&q=82",
    url: "#"
  },
  {
    id: "s-ai-job",
    title: "3 อาชีพที่ AI เข้ามาแทนแล้ว และ 3 อาชีพที่ยังปลอดภัย",
    duration: "1:02",
    tag: "#SHORTS",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/rfscVS0vtbw/hqdefault.jpg&w=360&h=640&fit=cover&output=jpg&q=82",
    url: "#"
  },
  {
    id: "s-gold",
    title: "ทองคำทะลุ $2,000 อีกแล้ว เกิดอะไรขึ้น?",
    duration: "0:45",
    tag: "#SHORTS",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/8jPQjjsBbIc/hqdefault.jpg&w=360&h=640&fit=cover&output=jpg&q=82",
    url: "#"
  },
  {
    id: "s-ev",
    title: "EV แบตเตอรี่หมดอายุ ทิ้งยังไงถึงจะไม่ทำลายโลก",
    duration: "1:15",
    tag: "#SHORTS",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/t8QEOBgLBQU/hqdefault.jpg&w=360&h=640&fit=cover&output=jpg&q=82",
    url: "#"
  },
  {
    id: "s-rate",
    title: "ดอกเบี้ยขึ้น = บ้านแพงขึ้น? อธิบายใน 60 วิ",
    duration: "0:55",
    tag: "#SHORTS",
    thumb: "https://images.weserv.nl/?url=i.ytimg.com/vi/HluANRwPyNo/hqdefault.jpg&w=360&h=640&fit=cover&output=jpg&q=82",
    url: "#"
  }
];

// ── PODCASTS ─────────────────────────────────────────────────────────────────
window.PODCASTS = [
  {
    id: "pod-tss-265",
    ep: "EP.265",
    title: "De-influencing คือจุดจบ Influencer Marketing หรือแค่การปรับตัว?",
    show: "THE SECRET SAUCE",
    duration: "52 นาที",
    cover: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2024/01/THE-SECRET-SAUCE-COVER.jpg&w=200&h=200&fit=cover&output=jpg&q=82",
    platforms: ["spotify", "apple", "youtube"],
    url: "https://thestandard.co/podcast/the-secret-sauce/"
  },
  {
    id: "pod-wealth-88",
    ep: "EP.88",
    title: "ลงทุนในยุค AI: พอร์ตแบบไหนที่ยังชนะตลาดได้ในปี 2026",
    show: "THE STANDARD WEALTH PODCAST",
    duration: "44 นาที",
    cover: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2024/01/WEALTH-PODCAST-COVER.jpg&w=200&h=200&fit=cover&output=jpg&q=82",
    platforms: ["spotify", "youtube"],
    url: "https://thestandard.co/podcast/the-standard-wealth-podcast/"
  },
  {
    id: "pod-tss-264",
    ep: "EP.264",
    title: "ทำไมบริษัทไทยยังกลัว ESG และใครได้ประโยชน์จากความกลัวนั้น",
    show: "THE SECRET SAUCE",
    duration: "48 นาที",
    cover: "https://images.weserv.nl/?url=thestandard.co/wp-content/uploads/2024/01/THE-SECRET-SAUCE-COVER.jpg&w=200&h=200&fit=cover&output=jpg&q=82",
    platforms: ["spotify", "apple", "youtube"],
    url: "https://thestandard.co/podcast/the-secret-sauce/"
  }
];
